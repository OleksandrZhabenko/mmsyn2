## Welcome to mmsyn2 home page!

mmsyn2 is the library that can be used for optimization of multiple (Ord a) => a -> b transformations.

