# Revision history for mmsyn2

## 0.1.2.0 -- 2019-09-24

* First version revised. From deprecated mm2. Some optimization changes.

## 0.1.3.0 -- 2019-09-27

* First release revised B. Some performance changes and changing the imported functions. 
Moreover, fixed constraints in cabal file. Make more exact the vector usage.

## 0.1.4.0 -- 2019-09-28

* First version revised C. Some performance improvements and changing the imported functions.

## 0.1.5.0 -- 2019-09-28

* First version revised D. Some performance improvements and changing the documentation.
The benchmark testing continues.


